# LINE Bot — Báo cáo kinh doanh (gọi bằng từ khóa "báo cáo")

Bot đọc 4 file Excel trong `/data`, tự tính:
1. **Tổng doanh thu dự kiến** tháng này vs tháng trước (cột **I - Doanh thu**)
2. **Chi tiết doanh thu tăng/giảm theo ngành hàng**, tách riêng 2 thẻ **FMCG** và **FRESH**
3. **Sản lượng dự kiến** tháng này vs tháng trước (cột **F - Sản lượng bán**)

Khi ai đó nhắn tin có chứa chữ **"báo cáo"** vào LINE OA, bot trả lời bằng 1 tin nhắn Flex Message dạng carousel 3 thẻ (vuốt ngang xem).

## 1. Cài đặt
```bash
npm install
```
File `.env` đã được điền sẵn `LINE_CHANNEL_ACCESS_TOKEN` anh gửi. Anh chỉ cần điền thêm **`LINE_CHANNEL_SECRET`** (lấy ở Console > kênh Messaging API > tab "Cài đặt cơ bản" > mục "Channel secret").

⚠️ Token anh gửi trong chat coi như đã lộ — sau khi setup xong, anh nên **Issue lại (reissue) Channel Access Token mới** trong Console rồi cập nhật vào `.env`, để token cũ không còn dùng được nữa.

## 2. Kiểm tra số liệu trước khi deploy (không cần LINE)
```bash
npm run test-report
```
Lệnh này in ra toàn bộ số liệu đã tính (tổng doanh thu, chi tiết từng ngành hàng, sản lượng) ra console để anh đối chiếu cho khớp trước khi gửi thật.

## 3. Chạy server
```bash
npm start
```

## 4. Trỏ Webhook (anh đã bật API/Webhook rồi thì chỉ cần đổi URL)
1. Vào kênh **Messaging API** > tab **Messaging API** > mục **Webhook settings**.
2. Điền: `https://<domain-cua-anh>/webhook`
3. Bật **Use webhook** = ON, bấm **Verify**.
4. Tắt **Auto-reply messages** / **Greeting messages** mặc định (LINE Official Account Manager) để tránh trả lời trùng.

## 5. Cập nhật dữ liệu mỗi tháng
Thư mục `/data` có 4 file cố định tên:
```
data/doanhthu_thang_truoc.xlsx     <- doanh thu tháng liền trước (đã đủ cả tháng)
data/doanhthu_thang_nay.xlsx       <- doanh thu tháng hiện tại (bao nhiêu ngày cũng được, bot tự chiếu cả tháng)
data/sanluong_thang_truoc.xlsx     <- sản lượng FRESH tháng liền trước
data/sanluong_thang_nay.xlsx       <- sản lượng FRESH tháng hiện tại
```
Mỗi khi có báo cáo mới, anh chỉ cần **xuất file từ hệ thống rồi ghi đè đúng 4 tên file trên** — không cần sửa code. Bot đọc lại file mỗi lần có người nhắn "báo cáo" nên luôn lấy số mới nhất.

Khi sang tháng mới, mở `config.js` sửa 2 dòng:
```js
DAYS_IN_TARGET_MONTH: 31,   // đổi số ngày của tháng đang dự phóng
LABEL_PREV_MONTH: 'Tháng 7',
LABEL_CURR_MONTH: 'Tháng 8 (dự kiến)',
```

## 6. Đổi từ khóa gọi bot
Mở `config.js`, sửa dòng:
```js
TRIGGER_KEYWORD: 'báo cáo',
```

## 7. Logic tính dự kiến (đã xác nhận với anh)
- Doanh thu: lấy **cột I "Doanh thu"** (không phải cột Y — file thực tế chỉ có tới cột L).
- FRESH = 5 ngành: Rau Củ Quả CL, Cá (Hải sản), Thịt, Trứng, Trái cây. Các ngành còn lại trong file doanh thu = FMCG.
- Tháng đang thiếu ngày dữ liệu → dự phóng = **(tổng đã có / số ngày đã có) × số ngày cả tháng**.
- Sản lượng: lấy **cột F "Sản lượng bán"** trong file FRESH.

## Cấu trúc project
```
line-bot-report/
├── server.js         # webhook, nhận tin nhắn, trả Flex Message
├── reportEngine.js   # đọc 4 file xlsx, tính tổng/chi tiết/dự phóng
├── flexBuilder.js     # build Flex Message carousel 3 thẻ
├── config.js          # từ khóa, danh sách FRESH, số ngày trong tháng, đường dẫn file
├── data/               # 4 file Excel nguồn — ghi đè mỗi tháng
├── test/testReport.js # in số liệu ra console để kiểm tra nhanh
├── .env                # token thật (đừng commit lên git)
└── .env.example
```
