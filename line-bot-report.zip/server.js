// server.js
require('dotenv').config();
const express = require('express');
const { middleware, Client } = require('@line/bot-sdk');
const config = require('./config');
const { buildReportData } = require('./reportEngine');
const { buildReportFlexMessage } = require('./flexBuilder');

const lineConfig = {
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET,
};

const app = express();
const client = new Client(lineConfig);

app.get('/', (req, res) => res.send('LINE report bot is running ✅'));

app.post('/webhook', middleware(lineConfig), async (req, res) => {
  try {
    const events = req.body.events || [];
    await Promise.all(events.map(handleEvent));
    res.status(200).end();
  } catch (err) {
    console.error('Webhook error:', err);
    res.status(500).end();
  }
});

async function handleEvent(event) {
  if (event.type !== 'message' || event.message.type !== 'text') return null;

  const text = (event.message.text || '').toLowerCase();
  const isReportRequest = text.includes(config.TRIGGER_KEYWORD.toLowerCase());
  if (!isReportRequest) return null; // không phải từ khóa -> im lặng

  try {
    const data = buildReportData();
    const flexMessage = buildReportFlexMessage(data);
    return client.replyMessage(event.replyToken, flexMessage);
  } catch (err) {
    console.error('Lỗi khi tạo báo cáo:', err);
    return client.replyMessage(event.replyToken, {
      type: 'text',
      text: 'Xin lỗi, hiện chưa đọc được dữ liệu báo cáo. Vui lòng kiểm tra lại file dữ liệu trong thư mục /data.',
    });
  }
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
