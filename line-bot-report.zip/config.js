// config.js
module.exports = {
  // Từ khóa gọi bot để nhận báo cáo (không phân biệt hoa thường, chỉ cần chứa từ này)
  TRIGGER_KEYWORD: 'báo cáo',

  // 5 ngành hàng thuộc nhóm FRESH — mọi ngành hàng khác trong file doanh thu được xếp vào FMCG
  FRESH_INDUSTRIES: ['Rau Củ Quả CL', 'Cá (Hải sản)', 'Thịt', 'Trứng', 'Trái cây'],

  // Số ngày của tháng đang dự phóng (tháng 8/2026 = 31 ngày). Đổi số này mỗi khi qua tháng mới.
  DAYS_IN_TARGET_MONTH: 31,

  // Nhãn hiển thị cho 2 tháng đang so sánh — đổi mỗi khi cập nhật file mới
  LABEL_PREV_MONTH: 'Tháng 7',
  LABEL_CURR_MONTH: 'Tháng 8 (dự kiến)',

  // Đường dẫn 4 file dữ liệu — thay file mới vào đây mỗi tháng, giữ nguyên tên file
  FILES: {
    revenuePrevMonth: __dirname + '/data/doanhthu_thang_truoc.xlsx',
    revenueCurrMonth: __dirname + '/data/doanhthu_thang_nay.xlsx',
    volumePrevMonth: __dirname + '/data/sanluong_thang_truoc.xlsx',
    volumeCurrMonth: __dirname + '/data/sanluong_thang_nay.xlsx',
  },
};
