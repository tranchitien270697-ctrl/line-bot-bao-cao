// test/testReport.js
// Chạy: npm run test-report
// In ra số liệu báo cáo tính từ 4 file trong /data để anh kiểm tra trước khi deploy.
const { buildReportData } = require('../reportEngine');

const data = buildReportData();

console.log('=== TỔNG DOANH THU ===');
console.log('Tháng trước:', Math.round(data.revenue.prevTotal).toLocaleString('vi-VN'), 'đ');
console.log('Tháng này (dự kiến):', Math.round(data.revenue.currProjectedTotal).toLocaleString('vi-VN'), 'đ');
console.log('Delta:', Math.round(data.revenue.delta).toLocaleString('vi-VN'), 'đ', `(${data.revenue.pct.toFixed(1)}%)`);

console.log('\n=== FMCG (theo delta giảm dần) ===');
data.revenueByIndustry.fmcg.forEach((x) =>
  console.log(x.industry.padEnd(50), Math.round(x.delta).toLocaleString('vi-VN'), x.pct === null ? 'N/A' : `${x.pct.toFixed(1)}%`)
);

console.log('\n=== FRESH (theo delta giảm dần) ===');
data.revenueByIndustry.fresh.forEach((x) =>
  console.log(x.industry.padEnd(50), Math.round(x.delta).toLocaleString('vi-VN'), x.pct === null ? 'N/A' : `${x.pct.toFixed(1)}%`)
);

console.log('\n=== SẢN LƯỢNG ===');
console.log('Tháng trước:', data.volume.prevTotal.toFixed(1));
console.log('Tháng này (dự kiến):', data.volume.currProjectedTotal.toFixed(1));
console.log('Delta:', data.volume.delta.toFixed(1), `(${data.volume.pct.toFixed(1)}%)`);
