// reportEngine.js
const XLSX = require('xlsx');
const config = require('./config');

// Đọc toàn bộ sheet đầu tiên ra mảng dòng thô (row = mảng theo cột A,B,C...)
function readRows(filePath, opts = {}) {
  const wb = XLSX.readFile(filePath, { cellDates: true, ...opts });
  const sheetName = wb.SheetNames[0];
  const sheet = wb.Sheets[sheetName];
  // header:1 -> mảng 2 chiều, dòng 0 là header, giữ nguyên vị trí cột
  return XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true, defval: null });
}

// Chuẩn hoá 1 ngày về chuỗi 'YYYY-MM-DD' dù cell là Date object hay chuỗi 'dd/mm/yyyy'
function normalizeDate(value) {
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, '0');
    const d = String(value.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  if (typeof value === 'string') {
    const parts = value.split('/'); // dd/mm/yyyy
    if (parts.length === 3) {
      const [d, m, y] = parts;
      return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
    }
  }
  return String(value);
}

/**
 * Đọc file doanh thu theo ngành hàng.
 * Cột cố định: D=Ngày xuất(idx3), H=Ngành hàng BHX(idx7), I=Doanh thu(idx8)
 */
function loadRevenueFile(filePath) {
  const rows = readRows(filePath);
  const byIndustry = {};
  const days = new Set();
  let total = 0;

  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row) continue;
    const date = row[3];
    const industry = row[7];
    const revenue = row[8];
    if (industry == null || revenue == null || typeof revenue !== 'number') continue;

    byIndustry[industry] = (byIndustry[industry] || 0) + revenue;
    total += revenue;
    if (date != null) days.add(normalizeDate(date));
  }

  return { byIndustry, total, dayCount: days.size };
}

/**
 * Đọc file sản lượng bán (FRESH). Cột cố định: A=Ngày xuất(idx0), E=Ngành hàng BHX(idx4), F=Sản lượng bán(idx5)
 */
function loadVolumeFile(filePath) {
  const rows = readRows(filePath);
  const byIndustry = {};
  const days = new Set();
  let total = 0;

  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row) continue;
    const date = row[0];
    const industry = row[4];
    const volume = row[5];
    if (industry == null || volume == null || typeof volume !== 'number') continue;

    byIndustry[industry] = (byIndustry[industry] || 0) + volume;
    total += volume;
    if (date != null) days.add(normalizeDate(date));
  }

  return { byIndustry, total, dayCount: days.size };
}

// Chiếu (dự phóng) một giá trị theo số ngày đã có dữ liệu lên cả tháng
function project(totalSoFar, dayCountSoFar, daysInMonth) {
  if (!dayCountSoFar) return 0;
  return (totalSoFar / dayCountSoFar) * daysInMonth;
}

function pctChange(curr, prev) {
  if (!prev) return null; // tránh chia 0
  return ((curr - prev) / prev) * 100;
}

/**
 * Tính toàn bộ báo cáo: tổng doanh thu, chi tiết theo ngành hàng (FMCG/FRESH), tổng sản lượng.
 */
function buildReportData() {
  const { FILES, FRESH_INDUSTRIES, DAYS_IN_TARGET_MONTH } = config;
  const freshSet = new Set(FRESH_INDUSTRIES);

  const revPrev = loadRevenueFile(FILES.revenuePrevMonth);
  const revCurr = loadRevenueFile(FILES.revenueCurrMonth);
  const volPrev = loadVolumeFile(FILES.volumePrevMonth);
  const volCurr = loadVolumeFile(FILES.volumeCurrMonth);

  // 1. Tổng doanh thu
  const revPrevTotal = revPrev.total;
  const revCurrProjected = project(revCurr.total, revCurr.dayCount, DAYS_IN_TARGET_MONTH);
  const revTotalDelta = revCurrProjected - revPrevTotal;
  const revTotalPct = pctChange(revCurrProjected, revPrevTotal);

  // 2. Chi tiết theo ngành hàng, tách FMCG / FRESH
  const allIndustries = new Set([...Object.keys(revPrev.byIndustry), ...Object.keys(revCurr.byIndustry)]);
  const fmcgList = [];
  const freshList = [];

  for (const industry of allIndustries) {
    const prevVal = revPrev.byIndustry[industry] || 0;
    const currValProjected = project(revCurr.byIndustry[industry] || 0, revCurr.dayCount, DAYS_IN_TARGET_MONTH);
    const delta = currValProjected - prevVal;
    const pct = pctChange(currValProjected, prevVal);
    const entry = { industry, delta, pct };
    if (freshSet.has(industry)) freshList.push(entry);
    else fmcgList.push(entry);
  }

  // Sắp xếp giảm dần theo mức tăng trưởng tuyệt đối để mục quan trọng lên đầu
  fmcgList.sort((a, b) => b.delta - a.delta);
  freshList.sort((a, b) => b.delta - a.delta);

  // 3. Sản lượng
  const volPrevTotal = volPrev.total;
  const volCurrProjected = project(volCurr.total, volCurr.dayCount, DAYS_IN_TARGET_MONTH);
  const volDelta = volCurrProjected - volPrevTotal;
  const volPct = pctChange(volCurrProjected, volPrevTotal);

  return {
    revenue: {
      prevTotal: revPrevTotal,
      currProjectedTotal: revCurrProjected,
      delta: revTotalDelta,
      pct: revTotalPct,
    },
    revenueByIndustry: {
      fmcg: fmcgList,
      fresh: freshList,
    },
    volume: {
      prevTotal: volPrevTotal,
      currProjectedTotal: volCurrProjected,
      delta: volDelta,
      pct: volPct,
    },
    meta: {
      revCurrDayCount: revCurr.dayCount,
      volCurrDayCount: volCurr.dayCount,
      daysInTargetMonth: DAYS_IN_TARGET_MONTH,
    },
  };
}

module.exports = { buildReportData, loadRevenueFile, loadVolumeFile };
