// sheetsClient.js
const https = require('https');
const config = require('./config');

// Tải nội dung CSV thô của 1 tab (gid) trong Google Sheet công khai (Anyone with link - Viewer)
function fetchCsv(gid) {
  const url = `https://docs.google.com/spreadsheets/d/${config.GOOGLE_SHEET_ID}/export?format=csv&gid=${gid}`;
  return new Promise((resolve, reject) => {
    https
      .get(url, (res) => {
        // Google trả 302 redirect trong vài trường hợp -> theo link mới
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          https
            .get(res.headers.location, (res2) => collectBody(res2, resolve, reject))
            .on('error', reject);
          return;
        }
        if (res.statusCode !== 200) {
          reject(new Error(`Không tải được Sheet (gid=${gid}), status=${res.statusCode}. Kiểm tra lại quyền chia sẻ "Bất kỳ ai có link - Người xem".`));
          return;
        }
        collectBody(res, resolve, reject);
      })
      .on('error', reject);
  });
}

function collectBody(res, resolve, reject) {
  let data = '';
  res.setEncoding('utf8');
  res.on('data', (chunk) => (data += chunk));
  res.on('end', () => resolve(data));
  res.on('error', reject);
}

// Parser CSV đơn giản, hỗ trợ field có dấu ngoặc kép chứa dấu phẩy bên trong
function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    const next = text[i + 1];

    if (inQuotes) {
      if (c === '"' && next === '"') {
        field += '"';
        i++;
      } else if (c === '"') {
        inQuotes = false;
      } else {
        field += c;
      }
    } else {
      if (c === '"') {
        inQuotes = true;
      } else if (c === ',') {
        row.push(field);
        field = '';
      } else if (c === '\n') {
        row.push(field);
        rows.push(row);
        row = [];
        field = '';
      } else if (c === '\r') {
        // bỏ qua, xử lý ở \n
      } else {
        field += c;
      }
    }
  }
  if (field.length || row.length) {
    row.push(field);
    rows.push(row);
  }
  return rows;
}

// Chuẩn hoá 1 chuỗi số kiểu Việt Nam (dấu phẩy thập phân) hoặc chuẩn quốc tế về Number
function parseVNNumber(raw) {
  if (raw == null) return null;
  let s = String(raw).trim();
  if (s === '') return null;
  s = s.replace(/\s/g, '');

  const hasComma = s.includes(',');
  const hasDot = s.includes('.');

  if (hasComma && hasDot) {
    if (s.lastIndexOf(',') > s.lastIndexOf('.')) {
      s = s.replace(/\./g, '').replace(',', '.'); // dấu chấm là ngăn cách nghìn, phẩy là thập phân
    } else {
      s = s.replace(/,/g, ''); // phẩy là ngăn cách nghìn
    }
  } else if (hasComma) {
    const parts = s.split(',');
    if (parts.length > 2) {
      s = parts.join(''); // nhiều dấu phẩy -> ngăn cách nghìn
    } else {
      s = s.replace(',', '.'); // 1 dấu phẩy -> thập phân kiểu VN
    }
  } else if (hasDot) {
    const parts = s.split('.');
    if (parts.length > 2) {
      s = parts.join(''); // nhiều dấu chấm -> ngăn cách nghìn
    }
    // 1 dấu chấm -> giữ nguyên, coi là thập phân chuẩn
  }

  const num = parseFloat(s);
  return isNaN(num) ? null : num;
}

// Lấy toàn bộ dữ liệu 1 tab dưới dạng mảng dòng (đã bỏ header)
async function fetchSheetRows(gid) {
  const csvText = await fetchCsv(gid);
  const rows = parseCsv(csvText);
  return rows.slice(1); // bỏ dòng header
}

module.exports = { fetchSheetRows, parseVNNumber };
