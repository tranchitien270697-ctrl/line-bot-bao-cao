// test/testReport.js
// Chạy: npm run test-report
// Tải dữ liệu trực tiếp từ Google Sheet và in số ra console để kiểm tra trước khi bật thật.
const { buildReportData } = require('../reportEngine');

(async () => {
  try {
    const data = await buildReportData();

    console.log('=== TỔNG DOANH THU ===');
    console.log('Tháng trước:', Math.round(data.revenue.prevTotal).toLocaleString('vi-VN'), 'đ');
    console.log('Tháng này (dự kiến):', Math.round(data.revenue.currProjectedTotal).toLocaleString('vi-VN'), 'đ');
    console.log('Delta:', Math.round(data.revenue.delta).toLocaleString('vi-VN'), 'đ', `(${data.revenue.pct.toFixed(1)}%)`);

    console.log('\n=== FMCG (theo delta giảm dần) ===');
    data.revenueByIndustry.fmcg.forEach((x) =>
      console.log(x.industry.padEnd(50), Math.round(x.delta).toLocaleString('vi-VN'), x.pct === null ? 'N/A' : `${x.pct.toFixed(1)}%`)
    );

    console.log('\n=== FRESH (theo delta giảm dần) ===');
    data.revenueByIndustry.fresh.forEach((x) =>
      console.log(x.industry.padEnd(50), Math.round(x.delta).toLocaleString('vi-VN'), x.pct === null ? 'N/A' : `${x.pct.toFixed(1)}%`)
    );

    console.log('\n=== SẢN LƯỢNG ===');
    console.log('Tháng trước:', data.volume.prevTotal.toFixed(1));
    console.log('Tháng này (dự kiến):', data.volume.currProjectedTotal.toFixed(1));
    console.log('Delta:', data.volume.delta.toFixed(1), `(${data.volume.pct.toFixed(1)}%)`);
  } catch (err) {
    console.error('LỖI:', err.message);
    process.exit(1);
  }
})();
