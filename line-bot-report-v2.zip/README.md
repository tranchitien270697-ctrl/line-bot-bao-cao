# LINE Bot — Báo cáo kinh doanh (đọc trực tiếp từ Google Sheet)

Khác bản trước: bot **không đọc file Excel local nữa**, mà gọi thẳng vào Google Sheet của anh mỗi khi có người nhắn "báo cáo". Anh chỉ cần sửa số liệu trên Sheet — không cần đụng vào code hay ghi đè file.

## 1. Điều kiện bắt buộc: Sheet phải public dạng "Xem"
Menu **Chia sẻ** → **Chung** → **Bất kỳ ai có đường liên kết** → quyền **Người xem**.
(Bot không cần đăng nhập Google, nên nếu để riêng tư bot sẽ không đọc được.)

## 2. Cài đặt
```bash
npm install
```
`.env` đã điền sẵn `LINE_CHANNEL_ACCESS_TOKEN`. Anh điền thêm `LINE_CHANNEL_SECRET` (Console > kênh Messaging API > "Cài đặt cơ bản").

⚠️ Token đã lộ trong chat — sau khi chạy được, anh **reissue token mới** trong Console.

## 3. Kiểm tra số liệu (không cần LINE)
```bash
npm run test-report
```
In toàn bộ số liệu ra console. Nếu số bị sai (ví dụ đọc nhầm dấu phẩy/chấm), gửi lại kết quả này cho em để em chỉnh `sheetsClient.js`.

## 4. Chạy server & trỏ Webhook
```bash
npm start
```
Vào Messaging API > Webhook settings > điền `https://<domain-cua-anh>/webhook` > bật **Use webhook** > **Verify**.
Tắt **Auto-reply / Greeting messages** mặc định để tránh trả lời trùng.

## 5. Cập nhật dữ liệu hàng tháng
Không cần đụng code — chỉ cần:
- Cập nhật số liệu ngay trên 4 tab Google Sheet (giữ nguyên tên tab và cấu trúc cột).
- Khi sang tháng mới, đổi 2 dòng trong `config.js`:
```js
DAYS_IN_TARGET_MONTH: 31,
LABEL_PREV_MONTH: 'Tháng 7',
LABEL_CURR_MONTH: 'Tháng 8 (dự kiến)',
```
- Nếu tạo tab mới cho tháng sau (thay vì ghi đè tab cũ), lấy `gid` mới từ URL (`...#gid=xxxx`) và cập nhật trong `config.js` mục `TAB_GIDS`.

## 6. Cấu trúc cột đang dùng (theo đúng Sheet anh gửi)
**Tab doanh thu** (`data/doanhthu_thang_truoc`, `data/doanhthu_thang_nay`):
`A=Ngày xuất, B=AM, C=Mã siêu thị, D=Loại kho, E=Ngành hàng BHX, F=Doanh thu, ...`
→ Bot lấy **cột F (Doanh thu)**.

**Tab sản lượng** (`data/sanluong_thang_truoc`, `data/sanluong_thang_nay`):
`A=Ngày xuất, B=Mã siêu thị, C=Tên siêu thị, D=Mã ngành hàng BHX, E=Ngành hàng BHX, F=Sản lượng bán, ...`
→ Bot lấy **cột F (Sản lượng bán)**.

FRESH = Rau Củ Quả CL, Cá (Hải sản), Thịt, Trứng, Trái cây. Còn lại = FMCG.
Tháng thiếu ngày dữ liệu → dự phóng = (tổng đã có / số ngày đã có) × số ngày cả tháng.

## Cấu trúc project
```
line-bot-report-v2/
├── server.js         # webhook, nhận tin nhắn, trả Flex Message
├── reportEngine.js   # gọi sheetsClient, tính tổng/chi tiết/dự phóng
├── sheetsClient.js    # fetch CSV từ Google Sheet công khai + parser số kiểu VN
├── flexBuilder.js     # build Flex Message carousel 3 thẻ
├── config.js           # sheet ID, gid từng tab, danh sách FRESH, số ngày trong tháng
├── test/testReport.js # in số liệu ra console để kiểm tra nhanh
├── .env                # token thật
└── .env.example
```

## Nếu bot báo lỗi không lấy được dữ liệu
- Kiểm tra lại Sheet đã để "Bất kỳ ai có link - Người xem" chưa (bước 1).
- Kiểm tra server đang chạy có kết nối Internet ra ngoài (một số VPS nội bộ chặn ra ngoài).
- Chạy `npm run test-report` để xem lỗi cụ thể.
