// flexBuilder.js
const config = require('./config');

const GREEN = '#06C755'; // tăng
const RED = '#FF334B'; // giảm
const GREY = '#8C8C8C';
const DARK = '#1A1A1A';

function formatVND(n) {
  const rounded = Math.round(n);
  return new Intl.NumberFormat('vi-VN').format(rounded) + ' đ';
}

function formatNumber(n, decimals = 0) {
  return new Intl.NumberFormat('vi-VN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(n);
}

function formatPct(pct) {
  if (pct === null) return 'N/A';
  const sign = pct >= 0 ? '+' : '';
  return `${sign}${pct.toFixed(1)}%`;
}

function deltaColor(n) {
  return n >= 0 ? GREEN : RED;
}

function arrow(n) {
  return n >= 0 ? '▲' : '▼';
}

// 1 dòng "Tên chỉ số | giá trị"
function kvRow(label, value, opts = {}) {
  return {
    type: 'box',
    layout: 'baseline',
    contents: [
      { type: 'text', text: label, size: 'sm', color: GREY, flex: 4 },
      {
        type: 'text',
        text: value,
        size: opts.size || 'sm',
        color: opts.color || DARK,
        align: 'end',
        flex: 5,
        weight: opts.weight || 'regular',
      },
    ],
  };
}

// 1 dòng ngành hàng: tên + delta + %
function industryRow({ industry, delta, pct }) {
  const color = deltaColor(delta);
  return {
    type: 'box',
    layout: 'vertical',
    margin: 'md',
    contents: [
      { type: 'text', text: industry, size: 'sm', color: DARK, wrap: true, weight: 'bold' },
      {
        type: 'box',
        layout: 'baseline',
        margin: 'xs',
        contents: [
          { type: 'text', text: `${arrow(delta)} ${formatVND(Math.abs(delta))}`, size: 'sm', color, flex: 3 },
          { type: 'text', text: formatPct(pct), size: 'sm', color, align: 'end', flex: 2, weight: 'bold' },
        ],
      },
    ],
  };
}

function buildSummaryBubble(data) {
  const { revenue, volume, meta } = data;
  return {
    type: 'bubble',
    size: 'mega',
    header: {
      type: 'box',
      layout: 'vertical',
      backgroundColor: '#06C755',
      paddingAll: 'lg',
      contents: [
        { type: 'text', text: '📊 BÁO CÁO KINH DOANH', color: '#FFFFFF', weight: 'bold', size: 'lg' },
        { type: 'text', text: `${config.LABEL_PREV_MONTH} vs ${config.LABEL_CURR_MONTH}`, color: '#FFFFFF', size: 'sm' },
      ],
    },
    body: {
      type: 'box',
      layout: 'vertical',
      spacing: 'md',
      contents: [
        { type: 'text', text: 'TỔNG DOANH THU', weight: 'bold', size: 'sm', color: GREY },
        kvRow(config.LABEL_PREV_MONTH, formatVND(revenue.prevTotal)),
        kvRow(config.LABEL_CURR_MONTH, formatVND(revenue.currProjectedTotal), { weight: 'bold', size: 'md' }),
        kvRow(
          'Tăng/giảm',
          `${arrow(revenue.delta)} ${formatVND(Math.abs(revenue.delta))} (${formatPct(revenue.pct)})`,
          { color: deltaColor(revenue.delta), weight: 'bold' }
        ),
        { type: 'separator', margin: 'lg' },
        { type: 'text', text: 'TỔNG SẢN LƯỢNG', weight: 'bold', size: 'sm', color: GREY, margin: 'lg' },
        kvRow(config.LABEL_PREV_MONTH, formatNumber(volume.prevTotal, 1)),
        kvRow(config.LABEL_CURR_MONTH, formatNumber(volume.currProjectedTotal, 1), { weight: 'bold', size: 'md' }),
        kvRow(
          'Tăng/giảm',
          `${arrow(volume.delta)} ${formatNumber(Math.abs(volume.delta), 1)} (${formatPct(volume.pct)})`,
          { color: deltaColor(volume.delta), weight: 'bold' }
        ),
        { type: 'separator', margin: 'lg' },
        {
          type: 'text',
          margin: 'lg',
          size: 'xxs',
          color: GREY,
          wrap: true,
          text: `* ${config.LABEL_CURR_MONTH} dự phóng từ ${meta.revCurrDayCount} ngày dữ liệu thực tế × ${meta.daysInTargetMonth} ngày/tháng.`,
        },
      ],
    },
  };
}

function buildIndustryBubble(title, emoji, color, list) {
  return {
    type: 'bubble',
    size: 'mega',
    header: {
      type: 'box',
      layout: 'vertical',
      backgroundColor: color,
      paddingAll: 'lg',
      contents: [
        { type: 'text', text: `${emoji} ${title}`, color: '#FFFFFF', weight: 'bold', size: 'lg' },
        { type: 'text', text: 'Doanh thu tăng/giảm dự kiến theo ngành hàng', color: '#FFFFFF', size: 'xs', wrap: true },
      ],
    },
    body: {
      type: 'box',
      layout: 'vertical',
      contents: list.length
        ? list.map(industryRow)
        : [{ type: 'text', text: 'Không có dữ liệu', size: 'sm', color: GREY }],
    },
  };
}

function buildReportFlexMessage(data) {
  const bubbles = [
    buildSummaryBubble(data),
    buildIndustryBubble('FMCG', '🛒', '#3E5CFF', data.revenueByIndustry.fmcg),
    buildIndustryBubble('FRESH', '🥬', '#00A86B', data.revenueByIndustry.fresh),
  ];

  return {
    type: 'flex',
    altText: `Báo cáo kinh doanh: doanh thu ${config.LABEL_CURR_MONTH} dự kiến ${data.revenue.pct >= 0 ? 'tăng' : 'giảm'} ${Math.abs(data.revenue.pct).toFixed(1)}% so với ${config.LABEL_PREV_MONTH}`,
    contents: { type: 'carousel', contents: bubbles },
  };
}

module.exports = { buildReportFlexMessage };
