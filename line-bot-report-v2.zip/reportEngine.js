// reportEngine.js
const config = require('./config');
const { fetchSheetRows, parseVNNumber } = require('./sheetsClient');

// Chuẩn hoá ngày dạng "dd/mm/yyyy" (như hiển thị trên Google Sheet) về 'YYYY-MM-DD'
function normalizeDate(value) {
  const s = String(value).trim();
  const parts = s.split('/');
  if (parts.length === 3) {
    const [d, m, y] = parts;
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
  }
  return s;
}

/**
 * Tab doanh thu (data/doanhthu_thang_truoc | data/doanhthu_thang_nay)
 * Cột: A=Ngày xuất(0) B=AM(1) C=Mã siêu thị(2) D=Loại kho(3) E=Ngành hàng BHX(4) F=Doanh thu(5) ...
 */
async function loadRevenueTab(gid) {
  const rows = await fetchSheetRows(gid);
  const byIndustry = {};
  const days = new Set();
  let total = 0;

  for (const row of rows) {
    if (!row || row.length < 6) continue;
    const date = row[0];
    const industry = row[4];
    const revenue = parseVNNumber(row[5]);
    if (!industry || revenue == null) continue;

    byIndustry[industry] = (byIndustry[industry] || 0) + revenue;
    total += revenue;
    if (date) days.add(normalizeDate(date));
  }

  return { byIndustry, total, dayCount: days.size };
}

/**
 * Tab sản lượng FRESH (data/sanluong_thang_truoc | data/sanluong_thang_nay)
 * Cột: A=Ngày xuất(0) B=Mã siêu thị(1) C=Tên siêu thị(2) D=Mã ngành hàng BHX(3) E=Ngành hàng BHX(4) F=Sản lượng bán(5) ...
 */
async function loadVolumeTab(gid) {
  const rows = await fetchSheetRows(gid);
  const byIndustry = {};
  const days = new Set();
  let total = 0;

  for (const row of rows) {
    if (!row || row.length < 6) continue;
    const date = row[0];
    const industry = row[4];
    const volume = parseVNNumber(row[5]);
    if (!industry || volume == null) continue;

    byIndustry[industry] = (byIndustry[industry] || 0) + volume;
    total += volume;
    if (date) days.add(normalizeDate(date));
  }

  return { byIndustry, total, dayCount: days.size };
}

function project(totalSoFar, dayCountSoFar, daysInMonth) {
  if (!dayCountSoFar) return 0;
  return (totalSoFar / dayCountSoFar) * daysInMonth;
}

function pctChange(curr, prev) {
  if (!prev) return null;
  return ((curr - prev) / prev) * 100;
}

async function buildReportData() {
  const { TAB_GIDS, FRESH_INDUSTRIES, DAYS_IN_TARGET_MONTH } = config;
  const freshSet = new Set(FRESH_INDUSTRIES);

  const [revPrev, revCurr, volPrev, volCurr] = await Promise.all([
    loadRevenueTab(TAB_GIDS.revenuePrevMonth),
    loadRevenueTab(TAB_GIDS.revenueCurrMonth),
    loadVolumeTab(TAB_GIDS.volumePrevMonth),
    loadVolumeTab(TAB_GIDS.volumeCurrMonth),
  ]);

  // 1. Tổng doanh thu
  const revPrevTotal = revPrev.total;
  const revCurrProjected = project(revCurr.total, revCurr.dayCount, DAYS_IN_TARGET_MONTH);
  const revTotalDelta = revCurrProjected - revPrevTotal;
  const revTotalPct = pctChange(revCurrProjected, revPrevTotal);

  // 2. Chi tiết theo ngành hàng, tách FMCG / FRESH
  const allIndustries = new Set([...Object.keys(revPrev.byIndustry), ...Object.keys(revCurr.byIndustry)]);
  const fmcgList = [];
  const freshList = [];

  for (const industry of allIndustries) {
    const prevVal = revPrev.byIndustry[industry] || 0;
    const currValProjected = project(revCurr.byIndustry[industry] || 0, revCurr.dayCount, DAYS_IN_TARGET_MONTH);
    const delta = currValProjected - prevVal;
    const pct = pctChange(currValProjected, prevVal);
    const entry = { industry, delta, pct };
    if (freshSet.has(industry)) freshList.push(entry);
    else fmcgList.push(entry);
  }

  fmcgList.sort((a, b) => b.delta - a.delta);
  freshList.sort((a, b) => b.delta - a.delta);

  // 3. Sản lượng
  const volPrevTotal = volPrev.total;
  const volCurrProjected = project(volCurr.total, volCurr.dayCount, DAYS_IN_TARGET_MONTH);
  const volDelta = volCurrProjected - volPrevTotal;
  const volPct = pctChange(volCurrProjected, volPrevTotal);

  return {
    revenue: { prevTotal: revPrevTotal, currProjectedTotal: revCurrProjected, delta: revTotalDelta, pct: revTotalPct },
    revenueByIndustry: { fmcg: fmcgList, fresh: freshList },
    volume: { prevTotal: volPrevTotal, currProjectedTotal: volCurrProjected, delta: volDelta, pct: volPct },
    meta: {
      revCurrDayCount: revCurr.dayCount,
      volCurrDayCount: volCurr.dayCount,
      daysInTargetMonth: DAYS_IN_TARGET_MONTH,
    },
  };
}

module.exports = { buildReportData };
