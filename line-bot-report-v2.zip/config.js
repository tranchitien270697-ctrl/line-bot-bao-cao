// config.js
module.exports = {
  TRIGGER_KEYWORD: 'báo cáo',

  FRESH_INDUSTRIES: ['Rau Củ Quả CL', 'Cá (Hải sản)', 'Thịt', 'Trứng', 'Trái cây'],

  DAYS_IN_TARGET_MONTH: 31,

  LABEL_PREV_MONTH: 'Tháng 7',
  LABEL_CURR_MONTH: 'Tháng 8 (dự kiến)',

  // ID của Google Sheet (lấy từ URL: .../spreadsheets/d/<ID>/edit...)
  GOOGLE_SHEET_ID: '1wQlsrIsXTAwWByZwmfOs3f4Hsuh9TmLdWHg_1ECMttE',

  // gid của từng tab (lấy từ URL: ...#gid=<số>)
  TAB_GIDS: {
    revenuePrevMonth: '0', // data/doanhthu_thang_truoc
    revenueCurrMonth: '1560618412', // data/doanhthu_thang_nay
    volumePrevMonth: '1085666896', // data/sanluong_thang_truoc
    volumeCurrMonth: '594018980', // data/sanluong_thang_nay
  },
};
